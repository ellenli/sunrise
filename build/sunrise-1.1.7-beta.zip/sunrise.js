// month-scroll disabler from https://github.com/alter-ego/google-calendar-scroll-disabler

$('#gridcontainer').on({
    'mousewheel': function(e) {
        if (e.target.id == 'el') return;
        e.preventDefault();
        e.stopPropagation();
    }
})

// show start time on week view events

let calendarEvents = document.getElementsByClassName("chip");

// event info
var eventText;
var eventHTML;
var startTime;

for (var i=0; i<calendarEvents.length; i++) {
  
  eventText = calendarEvents[i].textContent;
  eventHTML = calendarEvents[i].getElementsByClassName("cbrdcc")[0];

  if (undefined != eventHTML) {
    // remove dash from 30 min events
    calendarEvents[i].getElementsByClassName("cbrdcc")[0].innerHTML = calendarEvents[i].getElementsByClassName("cbrdcc")[0].innerHTML.replace(/-/g,'');
  } else {
    // change target class for >30 min events
    eventHTML = calendarEvents[i].getElementsByClassName("evt-lk")[0];
  }
  startTime = "<strong>" + eventText.substr(0,eventText.indexOf(' ')).replace(/\s/g,'') + " </strong>";
  $(startTime).insertBefore(eventHTML);
}
